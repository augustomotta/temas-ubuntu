flatpak install --user org.freecad.FreeCAD -y
flatpak install --user org.keepassxc.KeePassXC -y
