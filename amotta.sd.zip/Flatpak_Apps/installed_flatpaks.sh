flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.gimp.GIMP -y
flatpak install --system org.inkscape.Inkscape -y
flatpak install --system fr.handbrake.ghb -y
